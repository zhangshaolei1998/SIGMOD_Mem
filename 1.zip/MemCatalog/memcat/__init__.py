"""MemCatalog — a DBMS-style memory management system for LLM agents.

Module map
----------
memcatalog   Typed catalog (M0 sessions / M1 triples), entity index, version index
facts        Fact-triple materialized view + revision enforcement + renderer
query_log    Workload log (MoM): one entry per answered query, read back as
             per-session usage counts
memcat_v280  Entity scoring, revision cues, q_type normalisation
memcat_v281  Per-session entity matching
memcat_v288  Query pipeline: five layer switches, prompt assembly, MoM commit
memcat_v325  Planner: routes a question to POINT / AGGREGATE / COMPARE
"""
from .memcatalog import (
    build_memcatalog, extract_entities,
    render_temporal_catalog, render_entity_catalog, render_revision_catalog,
    MemCatalogResult,
)
from .facts import (
    build_fact_table, enforce_revision, render_fact_table,
    flush_cache as flush_facts_cache,
)
from .query_log import (
    record, popularity_score, flush_log, LogEntry,
)
from .memcat_v288 import (
    build_memcat_v288, commit_query, flush_all_caches,
    PlanV288, MemCatV288Result, PLAN_V288, DEFAULT_PLAN_V288,
)
from .memcat_v325 import classify_query, build_plan_prompt, extract_plan_letter

__all__ = [
    "build_memcatalog", "extract_entities",
    "render_temporal_catalog", "render_entity_catalog", "render_revision_catalog",
    "MemCatalogResult",
    "build_fact_table", "enforce_revision", "render_fact_table", "flush_facts_cache",
    "record", "popularity_score", "flush_log", "LogEntry",
    "build_memcat_v288", "commit_query", "flush_all_caches",
    "PlanV288", "MemCatV288Result", "PLAN_V288", "DEFAULT_PLAN_V288",
    "classify_query", "build_plan_prompt", "extract_plan_letter",
]
