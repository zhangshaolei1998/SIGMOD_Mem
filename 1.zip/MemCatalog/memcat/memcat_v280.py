# -*- coding: utf-8 -*-
"""v280 MemCatalog v2 — behind-the-scenes CBO.

v279 exposed catalog tables as prompt text; on large haystacks (LoCoMo)
the extra text competed with the actual conversation for model attention
and dropped F1 by up to 0.07.

v280 fixes the DBMS analogy: catalogs are read by the *planner*, not the
*executor*. Their influence shows only through:

  1. Session reordering  (Cat-E: sessions with more Q-entity hits go first)
  2. Session filtering    (Cat-T: if Q mentions a date, keep sessions in that
                            temporal neighborhood; otherwise keep all)
  3. Inline revision tag  (Cat-R: a single [REVISION] marker on flagged
                            sessions, no separate catalog block)

The model sees a plain directive prompt over a reordered/filtered view.
No catalog tables in the context. Directive projection (v32) unchanged.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .memcatalog import extract_entities, _REVISION_CUES, _STOP


# ============================================================
# Cat-E: entity coverage → per-session score (used to reorder)
# ============================================================

def _q_entities(question: str) -> set:
    ents = extract_entities(question)
    tokens = {t for t in re.findall(r"[a-z]{5,}", question.lower())
              if t not in _STOP}
    return ents | tokens


def entity_scores(question: str, sessions_text: List[str]) -> List[int]:
    q_ents = _q_entities(question)
    if not q_ents:
        return [0] * len(sessions_text)
    scores = []
    for txt in sessions_text:
        low = txt.lower()
        hits = sum(1 for e in q_ents if e.lower() in low)
        scores.append(hits)
    return scores


# ============================================================
# Cat-T: temporal filter (only when Q mentions a date-ish token)
# ============================================================

_DATE_RE = re.compile(
    r"\b(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|"
    r"\d{1,2}\s+(?:january|february|march|april|may|june|july|august|"
    r"september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\s+\d{4}|"
    r"(?:january|february|march|april|may|june|july|august|"
    r"september|october|november|december)\s+\d{4})\b",
    re.IGNORECASE,
)


def question_mentions_specific_date(question: str) -> bool:
    return bool(_DATE_RE.search(question or ""))


# ============================================================
# Cat-R: revision detection per session
# ============================================================

def revision_flags(sessions_text: List[str]) -> List[bool]:
    return [bool(_REVISION_CUES.search(t)) for t in sessions_text]


# ============================================================
# Planner: decide reorder / filter / inline-tag behaviour
# ============================================================

# question-type buckets where reordering by entity coverage is useful
REORDER_TYPES = {
    "temporal", "temporal-reasoning",
    "single-hop", "single-session-user", "single-session-assistant",
    "knowledge-update", "multi-hop", "multi-session",
    "single-session-preference", "preference",
}

# types where full sequential scan is essential (never trim)
KEEP_ALL_TYPES = {
    "open-ended", "multi-hop", "multi-session", "preference",
    "single-session-preference",
}


@dataclass
class PlanTrace:
    used_cat_e: bool = False
    used_cat_t: bool = False
    used_cat_r_count: int = 0
    reorder_applied: bool = False
    top_k_kept: int = 0


# ============================================================
# Assembly
# ============================================================

MEMCATALOG_PROMPT_V280 = """\
You are answering a question about a user based on their conversation history.

QUESTION: {question}

CONVERSATION HISTORY (chronological; sessions marked [REVISION] contain updates that OVERRIDE earlier same-topic statements):
{context}

Answer the question directly and concisely. Give ONLY the factual answer — no explanation, no hedging.
If the answer is a name, date, number, or yes/no, respond with JUST that.
If the question asks about a specific date, format it as "15 July 2023" and give a specific calendar date.
Prefer facts from later sessions over earlier ones for the same topic."""


@dataclass
class MemCatResult:
    prompt: str
    trace: PlanTrace


def _norm_qtype(qt: Optional[str]) -> str:
    if not qt:
        return ""
    q = str(qt).lower().strip()
    return {"1": "temporal", "2": "single-hop", "3": "open-ended",
            "4": "multi-hop", "5": "adversarial"}.get(q, q)


def build_memcat_v280(question: str,
                      sessions_text: List[str],
                      session_labels: List[str],
                      session_dates: List[Optional[str]],
                      q_type_hint: Optional[str] = None,
                      enable_reorder: bool = True,
                      enable_revision: bool = True,
                      today: Optional[str] = None) -> MemCatResult:
    q_type = _norm_qtype(q_type_hint)
    trace = PlanTrace()
    n = len(sessions_text)
    # 1. Cat-R inline flags
    if enable_revision:
        rev = revision_flags(sessions_text)
        trace.used_cat_r_count = sum(rev)
    else:
        rev = [False] * n
    # 2. Ordering: chronological is default; if REORDER_TYPES + entity signal,
    #    front-load high-entity sessions but keep the rest afterwards.
    #    Never TRIM — we learned trimming hurts on LoCoMo.
    date_order = sorted(range(n), key=lambda i: session_dates[i] or "")
    order = date_order[:]
    if enable_reorder and q_type in REORDER_TYPES:
        e_scores = entity_scores(question, sessions_text)
        if any(e_scores):
            # split: high-score first (by score desc), then low-score in chronological
            high = sorted([i for i in range(n) if e_scores[i] > 0],
                          key=lambda i: (-e_scores[i], session_dates[i] or ""))
            low = [i for i in date_order if e_scores[i] == 0]
            order = high + low
            trace.used_cat_e = True
            trace.reorder_applied = True
    trace.top_k_kept = len(order)
    # 3. Assemble
    parts = []
    for i in order:
        d = session_dates[i]
        rev_tag = " [REVISION]" if rev[i] else ""
        header = f"=== {session_labels[i]}" + (f" [{d}]" if d else "") + rev_tag + " ==="
        parts.append(f"{header}\n{sessions_text[i]}")
    context = "\n\n".join(parts)
    q_with_today = f"[Today: {today}]\n{question}" if today else question
    prompt = MEMCATALOG_PROMPT_V280.format(question=q_with_today, context=context)
    return MemCatResult(prompt=prompt, trace=trace)
