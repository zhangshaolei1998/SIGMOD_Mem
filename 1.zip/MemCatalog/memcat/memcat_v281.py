# -*- coding: utf-8 -*-
"""v281 MemCatalog — type-aware plan dispatch.

Empirical lessons from v279 + v280:
  - Displaying catalog tables as text hurts on large haystacks (v279 lost
    0.07 F1 on LoCoMo).
  - Reordering hurts temporal Qs (breaks chronological reasoning).
  - Revision markers help multi-hop / knowledge-update but hurt open-ended.
  - Different Q types want different plans — this is exactly why a CBO
    dispatches different execution plans per query pattern.

v281 keeps chronological order always, and per Q type applies only the
INDEX ANNOTATION that empirically helps that type:

  Q type                    | plan
  --------------------------+---------------------------------------------
  temporal (cat1, temporal-*) | pure V32 (no annotation)
  open-ended (cat3)          | pure V32
  preference                 | pure V32
  single-hop (cat2, sess-*)  | + per-session [Q-matches: e1, e2] tag
  knowledge-update           | + per-session [Q-matches] + [REVISION] tag
  multi-hop (cat4, multi-session) | + [REVISION] tag
  adversarial (cat5)         | pure V32
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .memcatalog import extract_entities, _REVISION_CUES, _STOP
from .memcat_v280 import entity_scores, revision_flags, _q_entities, _norm_qtype


# Which annotations does each Q type want?
PLAN_TABLE: Dict[str, Dict[str, bool]] = {
    "temporal":               {"entity_match": False, "revision": False},
    "temporal-reasoning":     {"entity_match": False, "revision": False},
    "open-ended":             {"entity_match": False, "revision": False},
    "adversarial":            {"entity_match": False, "revision": False},

    "single-hop":                 {"entity_match": True,  "revision": False},
    "single-session-user":        {"entity_match": True,  "revision": False},
    "single-session-assistant":   {"entity_match": True,  "revision": False},

    "single-session-preference":  {"entity_match": False, "revision": False},
    "preference":                 {"entity_match": False, "revision": False},

    "knowledge-update":       {"entity_match": True,  "revision": True},
    "multi-hop":              {"entity_match": False, "revision": True},
    "multi-session":          {"entity_match": False, "revision": True},
}

DEFAULT_PLAN = {"entity_match": False, "revision": False}


@dataclass
class PlanV281:
    q_type: str
    entity_match: bool
    revision: bool
    n_revision_hits: int = 0
    entities_used: List[str] = field(default_factory=list)


MEMCATALOG_PROMPT_V281 = """\
You are answering a question about a user based on their conversation history.

QUESTION: {question}

CONVERSATION HISTORY (chronological; session headers may include [matches: ...] listing question keywords found in that session, and [REVISION] marking sessions that update earlier statements):
{context}

Answer the question directly and concisely. Give ONLY the factual answer — no explanation, no hedging.
If the answer is a name, date, number, or yes/no, respond with JUST that.
If the question asks about a specific date, format it as "15 July 2023" and give a specific calendar date.
When a session is marked [REVISION], prefer its later statement over earlier statements about the same fact."""


@dataclass
class MemCatV281Result:
    prompt: str
    plan: PlanV281


def _per_session_matches(question: str, sessions_text: List[str]) -> List[List[str]]:
    q_ents = list(_q_entities(question))
    if not q_ents:
        return [[] for _ in sessions_text]
    out: List[List[str]] = []
    for txt in sessions_text:
        low = txt.lower()
        hits = [e for e in q_ents if e.lower() in low]
        # keep top 5 to avoid noisy tags on very long sessions
        out.append(hits[:5])
    return out


def build_memcat_v281(question: str,
                     sessions_text: List[str],
                     session_labels: List[str],
                     session_dates: List[Optional[str]],
                     q_type_hint: Optional[str] = None,
                     today: Optional[str] = None) -> MemCatV281Result:
    q_type = _norm_qtype(q_type_hint)
    p = PLAN_TABLE.get(q_type, DEFAULT_PLAN)
    plan = PlanV281(q_type=q_type,
                    entity_match=p["entity_match"],
                    revision=p["revision"])

    n = len(sessions_text)
    match_lists = _per_session_matches(question, sessions_text) if plan.entity_match else [[] for _ in range(n)]
    if plan.entity_match:
        plan.entities_used = sorted({e for lst in match_lists for e in lst})
    rev = revision_flags(sessions_text) if plan.revision else [False] * n
    if plan.revision:
        plan.n_revision_hits = sum(rev)

    # Chronological ORDER — always. No reorder.
    order = sorted(range(n), key=lambda i: session_dates[i] or "")

    parts: List[str] = []
    for i in order:
        d = session_dates[i]
        tags = []
        if d:
            tags.append(f"[{d}]")
        if match_lists[i]:
            tags.append(f"[matches: {', '.join(match_lists[i])}]")
        if rev[i]:
            tags.append("[REVISION]")
        header_tags = " " + " ".join(tags) if tags else ""
        parts.append(f"=== {session_labels[i]}{header_tags} ===\n{sessions_text[i]}")
    context = "\n\n".join(parts)

    q_with_today = f"[Today: {today}]\n{question}" if today else question
    prompt = MEMCATALOG_PROMPT_V281.format(question=q_with_today, context=context)
    return MemCatV281Result(prompt=prompt, plan=plan)
