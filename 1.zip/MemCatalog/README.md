# MemCatalog

Code for **MemCatalog: A DBMS-style Memory Management System for LLM Agents**.

MemCatalog stores an agent's conversation history as a typed catalog and answers
questions through three operators — `POINT`, `AGGREGATE`, `COMPARE` — selected by a
lexical planner. Two further components sit around that core: a second-order memory
that re-ranks sessions from a per-user workload log, and a cost-aware executor that
sizes each query's generation budget by its operator.

Everything here runs on the Python standard library. The only external dependency is
whatever backs your `generate_fn` callback (the LLM).

## Layout

```
memcat/
  memcatalog.py      Typed catalog: M0 raw sessions, M1 fact triples,
                     entity index I_e, version index
  facts.py           Fact-triple materialized view, revision enforcement,
                     render_fact_table
  query_log.py       Second-order memory: the per-user workload log
  memcat_v280.py     Entity scoring, revision cues, q_type normalisation
  memcat_v281.py     Per-session entity matching
  memcat_v288.py     Query pipeline: five layer switches, prompt assembly,
                     commit_query
  memcat_v325.py     Planner: routes a question to POINT / AGGREGATE / COMPARE
run_demo.py          End-to-end driver over examples/demo_conversation.json
examples/
  demo_conversation.json   Eight synthetic sessions + eight questions
MEMORY_HOW_IT_WORKS.md     Detailed walkthrough of storage, query execution,
                           and the workload log, with measured traces
```

## Quick start

```bash
python3 run_demo.py                  # full pipeline, prompts printed
python3 run_demo.py --show-prompt 0  # plan trace only
python3 run_demo.py --llm-cmd '<cmd that reads a prompt on stdin>'
```

`run_demo.py` walks one conversation question by question and prints, for each,
the operator route, the five layer switches, the entity set written to the log,
the MoM read result, and the assembled prompt. It then reports what the workload
log accumulated.

Without `--llm-cmd` the fact-triple extraction step emits nothing, so the `FACTS`
block is empty and the demo says so; every other layer runs normally. Supplying a
command enables the fact-triple path end to end.

## Using it as a library

```python
from memcat import build_memcat_v288, commit_query, classify_query

pattern = classify_query(question)              # 'POINT' | 'AGGREGATE' | 'COMPARE'

res = build_memcat_v288(
    question,
    sessions_text,                              # list[str], one entry per session
    session_labels,                             # e.g. ['S1', 'S2', ...]
    session_dates,                              # e.g. ['2023-01-20', ...]
    generate_fn,                                # callable(prompt) -> str
    scope="user-42",                            # the workload-log partition
    q_type_hint="2",                            # benchmark category, optional
    today="2023-04-10",                         # optional
)

answer = my_llm(res.prompt)
commit_query(res)                               # writes one workload-log entry
```

`generate_fn(prompt) -> str` is the single pluggable dependency. It is called once per
session for fact-triple extraction and must return the model completion; triples are
parsed from a JSON array of `[subject, predicate, object]` in that completion.

## The five layer switches

`build_memcat_v288` opens a subset of five rendering layers per query, from a static
table keyed on `q_type`:

| q_type | matches | revision | facts | hard_rev | mom |
|---|---|---|---|---|---|
| temporal, temporal-reasoning | F | F | F | F | F |
| open-ended, adversarial | F | F | F | F | F |
| preference, single-session-preference | F | F | T | F | F |
| single-hop, single-session-user, single-session-assistant | T | F | T | F | T |
| knowledge-update | T | T | T | T | T |
| multi-hop, multi-session | F | T | T | F | T |
| (default) | F | F | F | F | F |

Two lexical guards then refine the table: a coverage phrase (`how many`, `number of`,
`count of`, `total`, `all of`, `list all`, `which of the`, `multiple`, `each of`)
disables the `facts` summary for exhaustive questions, and a historical/current phrase
set decides whether `hard_rev` actually applies.

## Second-order memory

Each answered query appends one entry to a per-user workload log:

```python
{"q_type": ..., "q_entities": [...], "matched_sessions": [...]}
```

`popularity_score(scope, q_entities, q_type)` joins the current question against
earlier entries by entity overlap and returns a `session_label -> usage count` map.
Entries whose entity intersection is empty are skipped; entries of the same `q_type`
count double. Only sessions the entity index actually matched contribute counts, so
every score is a traceable access count.

The log influences ranking alone. It never changes what an operator computes.

## Component to database analogy

| MemCatalog | Database mechanism |
|---|---|
| M1 fact triples | `CREATE MATERIALIZED VIEW` |
| version index | MVCC versions / tombstones |
| entity index `I_e` | GIN-style inverted index |
| planner phrase tables | static query routing, no optimizer call |
| workload log | `pg_stat_user_indexes` / `pg_stat_all_tables` |
| popularity re-rank | self-tuning index selection |
| hard revision | `DISTINCT ON` upsert to the latest value |

## On-disk stores

Two paths are read at import time and can be overridden:

```bash
export V288_FACTS_CACHE=/path/to/facts_cache.json   # memoized triples per session
export V288_QUERY_LOG=/path/to/query_log.json       # workload log
```

`run_demo.py` points both at `./results/` unless already set.

## Requirements

Python 3.8 or newer, standard library only. See `requirements.txt`.
