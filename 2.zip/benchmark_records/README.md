# MemCatalog benchmark evaluation records

Per-question evaluation records for the MemCatalog system on four of the
benchmarks reported in the paper: LoCoMo, LongMemEval-v, EvoMem, DynamicMem.
Each line holds one question's identifier and category, the answer MemCatalog
produced for it, and the score that answer received.

## Layout

```
benchmark_records/
  summary.json              one row per benchmark, same figures as the table below
  locomo/
    records.jsonl           1540 questions
    summary.json
  longmemeval_v/
    records.jsonl            451 questions
    summary.json
  evomem/
    records.jsonl             30 questions
    summary.json
  dynamicmem/
    records.jsonl            240 questions
    summary.json
```

## Record schema

One JSON object per line:

```json
{"id": "conv-26-0",
 "category": "cat=2",
 "memcatalog_answer": "7 May 2023",
 "memcatalog_score": 1.0,
 "full_context_score": 0.46}
```

| field | meaning |
|---|---|
| `id` | question identifier inside the benchmark |
| `category` | the benchmark's own question category or state table |
| `memcatalog_answer` | answer text produced by MemCatalog |
| `memcatalog_score` | score of that answer, in `[0, 1]` |
| `full_context_score` | score of the plain full-context call on the same question; present in `locomo/`, `evomem/`, `dynamicmem/` |

## Benchmarks

| benchmark | metric | n | mean score | paper table cell |
|---|---|---|---|---|
| LoCoMo | token F1 | 1540 | 58.76 | 58.8 |
| LongMemEval-v | phrase-set F1 | 451 | 10.31 | 10.3 |
| EvoMem | loose F1 | 30 | 24.60 | 24.6 |
| DynamicMem | loose F1 | 240 | 34.93 | 34.9 |

Three of the four runs also record the plain full-context call, whose mean
reproduces the Full-Context row of the same table: LoCoMo 52.24 (52.3),
EvoMem 16.68 (16.7), DynamicMem 33.53 (33.5).

## Metrics

- **token F1** — token-level F1 between the answer and the gold answer,
  the metric LoCoMo reports.
- **phrase-set F1** — F1 over the normalised set of answer phrases, used by
  the LongMemEval-v variant here.
- **loose F1** — F1 over normalised tokens with the answer surface relaxed on
  format, used by EvoMem and DynamicMem.

Every score is a per-question value in `[0, 1]`. Multiplying the mean of
`memcatalog_score` by 100 gives the cell in the paper's main results table.

## Recomputing an aggregate

```bash
python3 -c "
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1])]
print(100 * sum(r['memcatalog_score'] for r in rows) / len(rows))
" locomo/records.jsonl
```

## Requirements

Python 3 standard library.
